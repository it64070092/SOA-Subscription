package com.example.membership.command.rest;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SubscribeUserRestModel {
    private String userId;
    private String channelId;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private boolean subscribed;
}

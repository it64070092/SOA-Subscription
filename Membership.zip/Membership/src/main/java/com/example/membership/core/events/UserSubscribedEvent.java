package com.example.membership.core.events;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserSubscribedEvent {
    private String subscriptionId;
    private String userId;
    private String channelId;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private boolean subscribed;

    public UserSubscribedEvent(String subscriptionId, String userId, String channelId, boolean subscribed, LocalDateTime startDate, LocalDateTime endDate) {
        this.subscriptionId = subscriptionId;
        this.userId = userId;
        this.channelId = channelId;
        this.subscribed = subscribed;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}

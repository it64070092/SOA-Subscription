package com.example.artist.command;

import lombok.Builder;
import lombok.Data;
import org.axonframework.modelling.command.TargetAggregateIdentifier;

@Data
@Builder
public class CreateArtistCommand {
    @TargetAggregateIdentifier
    private String name;
    private String album;
    private String biography;
    private String recordLabel;
    private int subcount;
}

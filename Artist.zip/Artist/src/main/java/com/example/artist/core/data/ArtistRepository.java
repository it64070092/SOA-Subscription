package com.example.artist.core.data;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ArtistRepository extends MongoRepository<ArtistEntity, String> {

//    @Query(value = "{userId:  '?0'}")
//    List<ArtistEntity> findByUserId(String userId);

    @Query(value = "{_id: ?0}")
    ArtistEntity findByChannelId(String channelId);
//
//    @Query("{userId : ?0, channelId : ?1}")
//    ArtistEntity findByUserIdAndChannelId(String userId, String channelId);


//    @Query(value = "{ 'userId' : ?0, 'channelId' : ?1 }")
//    UserSubscriptionEntity findByUserIdAndChannelId(String userId, String channelId);



}

package com.example.artist.core.service;

import com.example.artist.core.data.ArtistEntity;
import com.example.artist.core.data.ArtistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ArtistService {
    private ArtistRepository repository;


    @Autowired
    public ArtistService(ArtistRepository repository, MongoTemplate mongoTemplate) {
        this.repository = repository;
    }

    public ArtistEntity getArtist(String channelId){
        return repository.findByChannelId(channelId);
    }
    public List<ArtistEntity> getAllArtist(){
        return repository.findAll();
    }

}

package com.example.membership.command.rest;

import com.example.membership.command.UserSubscriptionCommand;
import com.example.membership.core.data.UserSubscriptionRepository;
import com.example.membership.core.service.SubscriptionService;
import com.example.membership.core.data.UserSubscriptionEntity;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.UUID;

@RestController
@RequestMapping("/subscription")
public class SubscriptionCommandController {

    private final Environment env;

    private final CommandGateway commandGateway;

    private final UserSubscriptionRepository userSubscriptionRepository;

    private final SubscriptionService subscriptionService;

    @Autowired
    public SubscriptionCommandController(Environment env, CommandGateway commandGateway, SubscriptionService subscriptionService, UserSubscriptionRepository userSubscriptionRepository) {
        this.env = env;
        this.commandGateway = commandGateway;
        this.subscriptionService = subscriptionService;
        this.userSubscriptionRepository = userSubscriptionRepository;
    }



    @PostMapping("/subscribe")
    public String subscribeArtist(@RequestBody SubscribeUserRestModel model){
        LocalDateTime startDate = LocalDateTime.now();
        LocalDateTime endDate = LocalDateTime.now().plusMonths(1);
        String results;
            UserSubscriptionCommand command = UserSubscriptionCommand.builder()
                    .subscriptionId(UUID.randomUUID().toString())
                    .userId(model.getUserId())
                    .channelId(model.getChannelId())
                    .subscribed(model.isSubscribed())
                    .startDate(startDate)
                    .endDate(endDate)
                    .build();
            try {
                results = commandGateway.sendAndWait(command);
            } catch (Exception e){
                results = e.getLocalizedMessage();
            }
//        }
        return results;
    }

    @PostMapping("/unsubscribe")
    public String unsubscribeArtist(@RequestBody SubscribeUserRestModel model) {
        UserSubscriptionEntity entity = subscriptionService.getUserIdAndChannelId(model.getUserId(), model.getChannelId());
        System.out.println(entity);
        return subscriptionService.unsubscribeFromArtist(entity);
    }

}

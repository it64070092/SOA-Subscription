package com.example.membership.query.rest;

import com.example.membership.core.data.UserSubscriptionEntity;
import com.example.membership.core.service.SubscriptionService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/subscription")
public class SubscriptionQueryController {

    private SubscriptionService subscriptionServicel;

    public SubscriptionQueryController(SubscriptionService subscriptionServicel) {
        this.subscriptionServicel = subscriptionServicel;
    }

    @PostMapping("/getUserSubscription")
    public List<UserSubscriptionEntity> getUserSubscription(@RequestBody UserSubscriptionRestModel model){
        System.out.println(model.getUserId());
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getUserSubscription(model.getUserId());

        return  subscriptionEntities;
    }

    @PostMapping("/getChannelSubscription")
    public List<UserSubscriptionEntity> getArtistSubscription(@RequestBody UserSubscriptionRestModel model){
        System.out.println(model.getUserId());
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getArtistSubscription(model.getChannelId());

        return  subscriptionEntities;
    }

    @PostMapping("/getChannelSubscriptionTotal")
    public String getArtistSubscriptionTotal(@RequestBody UserSubscriptionRestModel model){
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getArtistSubscription(model.getChannelId());

        return  "Total subscribe: " + subscriptionEntities.size();
    }

    @PostMapping("/getAllsubscription")
    public List<UserSubscriptionEntity> getArtistSubscriptionTotal(){
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getAllsubscription();

        return  subscriptionEntities;
    }


}

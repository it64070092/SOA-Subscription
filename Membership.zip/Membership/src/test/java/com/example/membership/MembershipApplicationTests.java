package com.example.membership;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MembershipApplicationTests {

    @Test
    void contextLoads() {
    }

}

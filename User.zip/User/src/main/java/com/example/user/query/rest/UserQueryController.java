package com.example.user.query.rest;

import com.example.user.core.data.UserEntity;
import com.example.user.core.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserQueryController {
    private UserService userService;

    public UserQueryController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/getUser")
    public UserEntity getUser(@RequestBody UserRestModel model){
        UserEntity user  = userService.getUser(model.get_id());
        return user;
    }

    @GetMapping("/getAllUser")
    public List<UserEntity> getUser(){
        List<UserEntity> user  = userService.getAllUser();
        return user;
    }
}

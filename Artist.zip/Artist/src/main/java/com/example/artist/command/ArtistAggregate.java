package com.example.artist.command;

import com.example.artist.core.events.ArtistCreateEvent;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.spring.stereotype.Aggregate;

import static org.axonframework.modelling.command.AggregateLifecycle.apply;

@Aggregate
public class ArtistAggregate {
    @AggregateIdentifier
    private String name;
    private String album;
    private String biography;
    private String recordLabel;
    private int subcount;

    public ArtistAggregate() {
    }



    @CommandHandler
    public ArtistAggregate(CreateArtistCommand createArtistCommand) {
        apply(new ArtistCreateEvent(
                    createArtistCommand.getName(),
                    createArtistCommand.getAlbum(),
                    createArtistCommand.getBiography(),
                    createArtistCommand.getRecordLabel(),
                    createArtistCommand.getSubcount()
                )
            );
    }

    @EventSourcingHandler
    public void on(ArtistCreateEvent artistCreateEvent){
        System.out.println("ON Artist AGGREGATE");
        this.name = artistCreateEvent.getName();
        this.album = artistCreateEvent.getAlbum();
        this.biography = artistCreateEvent.getBiography();
        this.recordLabel = artistCreateEvent.getRecordLabel();
        this.subcount = artistCreateEvent.getSubcount();
    }
}

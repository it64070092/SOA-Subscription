package com.example.artist.command.rest;

import com.example.artist.command.CreateArtistCommand;
import com.example.artist.core.data.ArtistRepository;
import com.example.artist.core.service.ArtistService;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/artist")
public class ArtistCommandController {

    private final Environment env;

    private final CommandGateway commandGateway;


    @Autowired
    public ArtistCommandController(Environment env, CommandGateway commandGateway) {
        this.env = env;
        this.commandGateway = commandGateway;
    }



    @PostMapping("/createArtist")
    public String createArtist(@RequestBody CreateArtistRestModel model){
        String results;
            CreateArtistCommand command = CreateArtistCommand.builder()
                    .name(model.getName())
                    .biography(model.getBiography())
                    .album(model.getAlbum())
                    .recordLabel(model.getRecordLabel())
                    .subcount(model.getSubcount())
                    .build();
            try {
                results = commandGateway.sendAndWait(command);
            } catch (Exception e){
                results = e.getLocalizedMessage();
            }
        return results;
    }
}

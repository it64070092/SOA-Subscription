package com.example.user.core.pojo;

public enum Role {
    USER,
    ADMIN
}

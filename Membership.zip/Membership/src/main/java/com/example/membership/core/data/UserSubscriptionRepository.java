package com.example.membership.core.data;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserSubscriptionRepository extends MongoRepository<UserSubscriptionEntity, String> {

    @Query(value = "{userId:  '?0'}")
    List<UserSubscriptionEntity> findByUserId(String userId);

    @Query(value = "{channelId:  '?0'}")
    List<UserSubscriptionEntity> findByChannelId(String channelId);

    @Query("{userId : '?0', channelId : '?1'}")
    UserSubscriptionEntity findByUserIdAndChannelId(String userId, String channelId);


//    @Query(value = "{ 'userId' : ?0, 'channelId' : ?1 }")
//    UserSubscriptionEntity findByUserIdAndChannelId(String userId, String channelId);



}

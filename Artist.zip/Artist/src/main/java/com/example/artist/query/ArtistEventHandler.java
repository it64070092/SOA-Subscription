package com.example.artist.query;

import com.example.artist.core.data.ArtistEntity;
import com.example.artist.core.data.ArtistRepository;
import com.example.artist.core.events.ArtistCreateEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class ArtistEventHandler {

    private final ArtistRepository artistRepository;

    public ArtistEventHandler(ArtistRepository artistRepository){
        this.artistRepository = artistRepository;
    }

    @EventHandler
    public void on(ArtistCreateEvent event){
        ArtistEntity artistEntity = new ArtistEntity();
        BeanUtils.copyProperties(event, artistEntity);
        artistRepository.save(artistEntity);
    }

}

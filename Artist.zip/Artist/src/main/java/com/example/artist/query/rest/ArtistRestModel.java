package com.example.artist.query.rest;

import lombok.Data;

@Data
public class ArtistRestModel {
    private String _id;
    private String name;
    private String album;
    private String biography;
    private String recordLabel;
    private int subcount;
}

package com.example.artist.core.events;

import lombok.Data;

@Data
public class ArtistCreateEvent {
    private String name;
    private String album;
    private String biography;
    private String recordLabel;
    private int subcount;

    public ArtistCreateEvent(String name, String album, String biography, String recordLabel, int subcount) {
        this.name = name;
        this.album = album;
        this.biography = biography;
        this.recordLabel = recordLabel;
        this.subcount = subcount;
    }
}

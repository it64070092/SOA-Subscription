package com.example.membership.View;

class SubscribeView {

}
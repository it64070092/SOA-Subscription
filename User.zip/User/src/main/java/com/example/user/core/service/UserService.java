package com.example.user.core.service;

import com.example.user.core.data.UserEntity;
import com.example.user.core.data.UserRepository;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public UserEntity getUser(String userId){
        return userRepository.findByuserId(userId);
    }

    public UserEntity getUserByusername(String username){
        return userRepository.findByusername(username);
    }

    public UserEntity getUserByEmail(String email){
        return userRepository.findByEmail(email);
    }

    public List<UserEntity> getAllUser(){
        return userRepository.findAll();
    }

//    public UserEntity findUserWithEmail(String email){
//        return this.userRepository.findUserWithEmail(email);
//    }
}

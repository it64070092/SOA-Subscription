package com.example.membership.core.service;

import com.example.artist.core.data.ArtistEntity;
import com.example.artist.core.data.ArtistRepository;
import com.example.membership.core.data.UserSubscriptionEntity;
import com.example.membership.core.data.UserSubscriptionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SubscriptionService {
    private UserSubscriptionRepository repository;

    public SubscriptionService(UserSubscriptionRepository repository) {
        this.repository = repository;
    }

    public List<UserSubscriptionEntity> getUserSubscription(String userId){
        return repository.findByUserId(userId);
    }

    public List<UserSubscriptionEntity> getArtistSubscription(String userId){
        return repository.findByChannelId(userId);
    }

    public UserSubscriptionEntity getUserIdAndChannelId(String userId, String channelId){
        return repository.findByUserIdAndChannelId(userId, channelId);
    }

    public List<UserSubscriptionEntity> getAllsubscription(){
        return repository.findAll();
    }


    public String unsubscribeFromArtist(UserSubscriptionEntity entity) {
        try{
            repository.deleteById(entity.get_id());
            return "Successfully unsubscribe from " + entity.getChannelId();
         }catch(Exception e){
            return e.getLocalizedMessage();
         }
    }
}

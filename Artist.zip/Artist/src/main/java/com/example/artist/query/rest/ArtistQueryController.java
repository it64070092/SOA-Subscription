package com.example.artist.query.rest;

import com.example.artist.core.data.ArtistEntity;
import com.example.artist.core.service.ArtistService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/artist")
public class ArtistQueryController {

    private ArtistService artistServicel;

    public ArtistQueryController(ArtistService artistServicel) {
        this.artistServicel = artistServicel;
    }

    @PostMapping("/getChannel")
    public Optional<ArtistEntity> getArtistSubscription(@RequestBody ArtistRestModel model){
        Optional<ArtistEntity> artist  = artistServicel.getArtist(model.get_id());

        return  artist;
    }

    @GetMapping("/getAllChannel")
    public List<ArtistEntity> getArtistSubscription(){
        List<ArtistEntity> artist  = artistServicel.getAllArtist();

        return  artist;
    }

}

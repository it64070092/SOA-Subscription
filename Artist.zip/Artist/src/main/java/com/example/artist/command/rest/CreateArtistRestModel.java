package com.example.artist.command.rest;

import lombok.Data;

@Data
public class CreateArtistRestModel {
    private String name;
    private String album;
    private String biography;
    private String recordLabel;
    private int subcount;
}

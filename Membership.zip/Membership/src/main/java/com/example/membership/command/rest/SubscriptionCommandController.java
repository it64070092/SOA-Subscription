package com.example.membership.command.rest;

import com.example.membership.command.UserSubscriptionCommand;
import com.example.membership.core.service.SubscriptionService;
import com.example.membership.core.data.UserSubscriptionEntity;
import com.example.user.core.data.UserEntity;
import com.example.user.core.data.UserRepository;
import com.example.user.core.service.UserService;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/subscription")
public class SubscriptionCommandController {

    private final Environment env;

    private final CommandGateway commandGateway;

    private final UserService userService;

    private final UserRepository userRepository;
    private final SubscriptionService subscriptionService;

    @Autowired
    public SubscriptionCommandController(Environment env, CommandGateway commandGateway, UserService userService, SubscriptionService subscriptionService, UserRepository userRepository) {
        this.env = env;
        this.commandGateway = commandGateway;
        this.userService = userService;
        this.subscriptionService = subscriptionService;
        this.userRepository = userRepository;
    }



    @PostMapping("/subscribe")
    public String subscribeArtist(@RequestBody SubscribeUserRestModel model){
        LocalDateTime startDate;
        LocalDateTime endDate;
        String results = "";

        UserSubscriptionEntity existingSubscription = subscriptionService.getUserIdAndChannelId(model.getUserId(), model.getChannelId());

        UserEntity entity = userService.getUser(model.getUserId());


        if (existingSubscription != null && entity.getCredit() > 35) {
            entity.setCredit(entity.getCredit() - 35);
            startDate = existingSubscription.getStartDate();
            endDate = existingSubscription.getEndDate().plusMinutes(5);
            existingSubscription.setStartDate(startDate);
            existingSubscription.setEndDate(endDate);
            subscriptionService.updateSubscription(existingSubscription);
            userRepository.save(entity);
            results = "Success update";
        } else if(existingSubscription == null && entity.getCredit() > 35) {
            startDate = LocalDateTime.now();
            endDate = LocalDateTime.now().plusMinutes(5);
            UserSubscriptionCommand command = UserSubscriptionCommand.builder()
                    .subscriptionId(UUID.randomUUID().toString())
                    .userId(model.getUserId())
                    .channelId(model.getChannelId())
                    .subscribed(true)
                    .startDate(startDate)
                    .endDate(endDate)
                    .build();
            try {
                results = commandGateway.sendAndWait(command);
            } catch (Exception e){
                results = e.getLocalizedMessage();
            }
        } else {
            UserSubscriptionEntity entitySubscription = subscriptionService.getUserIdAndChannelId(model.getUserId(), model.getChannelId());
            results = "You don't have enough credits";
            subscriptionService.unsubscribeFromArtist(entitySubscription);
        }

        return results;
    }

    @PostMapping("/unsubscribe")
    public String unsubscribeArtist(@RequestBody SubscribeUserRestModel model) {
        UserSubscriptionEntity entity = subscriptionService.getUserIdAndChannelId(model.getUserId(), model.getChannelId());
        entity.setSubscribed(false);
        if(LocalDateTime.now().equals(entity.getEndDate())){
            subscriptionService.unsubscribeFromArtist(entity);
        }
        return "You are not subscriber of " + model.getChannelId() + "anymore";
    }

}

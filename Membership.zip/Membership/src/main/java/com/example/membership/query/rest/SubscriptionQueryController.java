package com.example.membership.query.rest;

import com.example.membership.core.data.UserSubscriptionEntity;
import com.example.membership.core.service.SubscriptionService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.List;

@RestController
@RequestMapping("/subscription")
public class SubscriptionQueryController {

    private SubscriptionService subscriptionServicel;

    public SubscriptionQueryController(SubscriptionService subscriptionServicel) {
        this.subscriptionServicel = subscriptionServicel;
    }

    @PostMapping("/getUserSubscription")
    public List<UserSubscriptionEntity> getUserSubscription(@RequestBody UserSubscriptionRestModel model){
        System.out.println(model.getUserId());
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getUserSubscription(model.getUserId());

        return  subscriptionEntities;
    }

    @PostMapping("/getChannelSubscription")
    public List<UserSubscriptionEntity> getArtistSubscription(@RequestBody UserSubscriptionRestModel model){
        System.out.println(model.getUserId());
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getArtistSubscription(model.getChannelId());

        return  subscriptionEntities;
    }

    @PostMapping("/getChannelSubscriptionTotal")
    public String getArtistSubscriptionTotal(@RequestBody UserSubscriptionRestModel model){
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getArtistSubscription(model.getChannelId());

        return  "Total subscribe: " + subscriptionEntities.size();
    }

    @PostMapping("/getAllsubscription")
    public List<UserSubscriptionEntity> getArtistSubscriptionTotal(){
        List<UserSubscriptionEntity> subscriptionEntities  = subscriptionServicel.getAllsubscription();

        return  subscriptionEntities;
    }

    @PostMapping("/getSubsciptionDuration")
    public String getSubsciptionDuration(@RequestBody UserSubscriptionRestModel model){
        UserSubscriptionEntity subscriptionEntity = subscriptionServicel.getUserIdAndChannelId(model.getUserId(), model.getChannelId());

        LocalDateTime startDate = subscriptionEntity.getStartDate();
        LocalDateTime endDate = subscriptionEntity.getEndDate();

        // Calculate the period between start and end dates
        Period period = calculatePeriod(startDate, endDate);

        System.out.println("Years " + period.getYears() + "Months " + period.getMonths());

        // Build the result String
        String result = buildResultString(period);

        return result;
    }

    private Period calculatePeriod(LocalDateTime startDate, LocalDateTime endDate) {
        LocalDate startLocalDate = startDate.toLocalDate();
        LocalDate endLocalDate = endDate.toLocalDate();

        return Period.between(startLocalDate, endLocalDate);
    }

    private String buildResultString(Period period) {
        int years = period.getYears();
        int months = period.getMonths();

        if (years > 0) {
            return String.format("Expires in %d years and %d months", years, months);
        } else if (years == 0 && months > 0) {
            return String.format("Expires in %d months", months);
        } else {
            return "Subscription has expired";
        }
    }

}

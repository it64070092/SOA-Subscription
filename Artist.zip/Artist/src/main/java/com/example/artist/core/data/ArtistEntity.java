package com.example.artist.core.data;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serial;
import java.io.Serializable;

@Data
@Document("Artist")
@Entity
public class ArtistEntity implements Serializable {

    @Id
    private String _id;
    private String name;
    private String album;
    private String biography;
    private String recordLabel;
    private int subcount;
}
